using Avalonia;
using Avalonia.Controls;
using Avalonia.Markup.Xaml;

namespace TrueText;

public partial class SplashScreen : Window
{
    public SplashScreen()
    {
        InitializeComponent();
    }
}